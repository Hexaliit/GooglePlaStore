import 'package:flutter/material.dart';
import 'package:rezataster/free_screen.dart';


class TypeScreen extends StatefulWidget {
  @override
  _TypeScreenState createState() => _TypeScreenState();
}

class _TypeScreenState extends State<TypeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new Container(
        height: MediaQuery.of(context).size.height,
        child: new Column(
          children: [
            SizedBox(height: 10,),
            GestureDetector(
              onTap: () {
                // print(ratingRange[index]);
                Navigator.of(context).push(
                    new MaterialPageRoute(builder: (context) => FreeScreen(type: "free",))
                );
              },
              child: new Container(
                margin: EdgeInsets.all(10),
                decoration: new BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border(
                        left: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        ),
                        right: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        ),
                        bottom: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        ),
                        top: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        )
                    )

                ),
                height: 40,
                child: new Center(child: new Text("free")),
              ),
            ),

            SizedBox(height: 10,),
            GestureDetector(
              onTap: () {
                // print(ratingRange[index]);
                Navigator.of(context).push(
                    new MaterialPageRoute(builder: (context) => FreeScreen(type: "paid",))
                );
              },
              child: new Container(
                margin: EdgeInsets.all(10),
                decoration: new BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border(
                        left: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        ),
                        right: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        ),
                        bottom: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        ),
                        top: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        )
                    )

                ),
                height: 40,
                child: new Center(child: new Text("Paid")),
              ),
            )
          ],
        ),
      )
    );
  }
}
