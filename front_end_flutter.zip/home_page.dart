import 'package:fancy_bottom_navigation/fancy_bottom_navigation.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rezataster/category.dart';
import 'package:rezataster/home_item.dart';
import 'package:rezataster/profile.dart';
import 'package:rezataster/saved_app.dart';
import 'package:rezataster/search_screen.dart';
import 'package:rezataster/typeScreen.dart';

class MainHomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<MainHomePage> {
  int page = 2;
  List pages= [RatingScreen(), GenresScreen(), HomeItem(), CategoryScreen(), TypeScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.purple,
        title: Container(
          width: MediaQuery.of(context).size.width,
          decoration: new BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: Colors.white
          ),
          child: new TextField(
            decoration: new InputDecoration(

              prefixIcon: new Icon(Icons.search , color: Colors.grey,),
              border: InputBorder.none,
              hintText: "Search..."
            ),
            readOnly: true,
            onTap: () {
              Navigator.of(context).push(
                new MaterialPageRoute(builder: (context) => SearchScreen())
              );
            },
          ),
        ),
      ),
      body: pages[page],

      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        items: [
          BottomNavigationBarItem(icon: Icon(CupertinoIcons.star_fill), title: new Text('rating')),
          BottomNavigationBarItem(icon: Icon(Icons.videogame_asset), title: new Text('genres')),
          BottomNavigationBarItem(icon: Icon(Icons.apps),title: new Text('apps')),
          BottomNavigationBarItem(icon: Icon(Icons.category),title: new Text('category')),
          BottomNavigationBarItem(icon: Icon(Icons.attach_money),title: new Text('type')),


        ],
        selectedItemColor: Colors.orangeAccent[700],
        unselectedItemColor: Colors.grey,

        currentIndex: page,
        onTap: (int x) {
          setState(() {
            page = x;

          });
        },
      )
      // new FancyBottomNavigation(
      //   tabs: [
      //     TabData(iconData: CupertinoIcons.profile_circled,
      //         title: "profile"
      //     ),
      //     TabData(iconData: Icons.save,
      //         title: "wishList"
      //     ),
      //     TabData(iconData: CupertinoIcons.home,
      //         title: "HomePage"
      //     ),
      //     TabData(iconData: Icons.category,
      //         title: "category"
      //     ),
      //
      //   ],
      //
      //   onTabChangedListener: (int x) {
      //     setState(() {
      //       page = x;
      //       print(x);
      //     });
      //   },
      //
      //   initialSelection: page,
      //   barBackgroundColor: Colors.white,
      //   circleColor: Colors.orangeAccent[700],
      //   activeIconColor: Colors.purple,
      //   inactiveIconColor: Colors.grey,
      //   textColor: Colors.purple,
      //
      // ),
    );
  }
}
