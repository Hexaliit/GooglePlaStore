import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rezataster/appsModule.dart';

class ShowDetail extends StatefulWidget {

  final AppsModule app;
  ShowDetail({this.app});


  @override
  _ShowDetailState createState() => _ShowDetailState();
}

class _ShowDetailState extends State<ShowDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: new Stack(
          children: [

            new Container(

              height: MediaQuery.of(context).size.height/2,
              // child: new Text(widget.app.name),
              decoration: new BoxDecoration(
                borderRadius: BorderRadius.only(bottomRight: Radius.circular(15), bottomLeft: Radius.circular(15)),
                color: Colors.purple,

              ),
            ),

            new Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: new EdgeInsets.only(top: 40),
                child: new IconButton(icon: Icon(Icons.bookmark_border , color: Colors.white, size: 30,), onPressed: () {
                  return null;
                }),
              ),
            ),
            new Align(
              alignment: Alignment.topLeft,
              child: Container(child: new Text(widget.app.name,style: new TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.white),),margin: EdgeInsets.only(top: 100,left: 20),),
            ),
            new Align(
              alignment: Alignment.bottomCenter,
              child: new Container(
                decoration: new BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border(
                    left: BorderSide(
                      color: Colors.grey,
                      style: BorderStyle.solid
                    ),
                    right: BorderSide(
                          color: Colors.grey,
                          style: BorderStyle.solid
                      ),
                    bottom: BorderSide(
                          color: Colors.grey,
                          style: BorderStyle.solid
                      ),
                    top: BorderSide(
                          color: Colors.grey,
                          style: BorderStyle.solid
                      )
                  )

                ),
                width: MediaQuery.of(context).size.width,
                margin: EdgeInsets.all(10),
                height: MediaQuery.of(context).size.height/1.3,
                child: new Column(
                  children: [
                    new SizedBox(height: 10,),
                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.category, color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.category, style: new TextStyle(fontSize: 20))
                      ],
                    ),
                    SizedBox(height: 10,),

                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.star_rate, color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.rating, style: new TextStyle(fontSize: 20),),
                        new SizedBox(width: MediaQuery.of(context).size.width/3,),
                        new Icon(Icons.rate_review,color: Colors.purple, size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.review, style: new TextStyle(fontSize: 20),),

                      ],
                    ),
                    new SizedBox(height: 10,),
                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.format_size, color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.size, style: new TextStyle(fontSize: 13),),
                        new SizedBox(width: MediaQuery.of(context).size.width/3,),
                        new Icon(Icons.save,color: Colors.purple, size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.installs, style: new TextStyle(fontSize: 13),),

                      ],
                    ),
                    new SizedBox(height: 10,),
                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.merge_type, color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.type, style: new TextStyle(fontSize: 14),),
                        new SizedBox(width: MediaQuery.of(context).size.width/3,),
                        new Icon(Icons.money,color: Colors.purple, size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.price, style: new TextStyle(fontSize: 20),),

                      ],
                    ),
                    new SizedBox(height: 10,),
                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.account_box_outlined, color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.content_range, style: new TextStyle(fontSize: 15),),
                        new SizedBox(width: MediaQuery.of(context).size.width/4,),
                        new Icon(Icons.android,color: Colors.purple, size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.android_veersion, style: new TextStyle(fontSize: 14),),

                      ],
                    ),
                    new SizedBox(height: 10,),
                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.toc_sharp , color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.genres, style: new TextStyle(fontSize: 20))
                      ],
                    ),
                    SizedBox(height: 10,),
                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.last_page, color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.last_update, style: new TextStyle(fontSize: 20))
                      ],
                    ),
                    SizedBox(height: 10,),
                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.trending_up_rounded, color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.current_version, style: new TextStyle(fontSize: 20))
                      ],
                    ),
                    SizedBox(height: 10,),
                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.create_rounded, color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.created_at, style: new TextStyle(fontSize: 20))
                      ],
                    ),
                    SizedBox(height: 10,),
                    new Row(
                      children: [
                        new SizedBox(width: 10,),
                        new Icon(Icons.update_rounded, color: Colors.purple,size: 30,),
                        new SizedBox(width: 20,),
                        new Text(widget.app.updated_at, style: new TextStyle(fontSize: 20))
                      ],
                    ),
                    SizedBox(height: 10,),


                  ],
                ),
              ),
            )
          ],
        ),
    );
  }
}
