import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:rezataster/appsModule.dart';
import 'package:rezataster/cartshow_page.dart';
import 'package:rezataster/home_item.dart';

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {

  String name;
  List appSearch = new List();
  Future <dynamic> app;

  getItem(int id) async {
    
    var response = await http.get("http://se.bot-telegram99.ir/api/app/${id}");
    Map<String , dynamic> jsonData = json.decode(response.body);
    print(jsonData);
    return AppsModule.fromJson(jsonData["app"]);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    appSearch.addAll(HomeItemState.allApp);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
          backgroundColor: Colors.purple,
          title: Container(
            width: MediaQuery.of(context).size.width,
            decoration: new BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.white
            ),
            child: new TextField(
              decoration: new InputDecoration(

                  suffixIcon: new IconButton(
                    icon: Icon(Icons.search , color: Colors.grey,) ,
                    onPressed: () {

                      setState(() {
                        int id;
                        appSearch.forEach((element) {
                          if(element.name == name) {
                            id = element.id;
                          }
                        });
                        app = getItem(id);

                      });
                      // print(app.toString());
                    },
                  ),
                  border: InputBorder.none,
                  hintText: "Search..."
              ),
              onChanged: (value) {
                setState(() {
                  name = value;
                });
              },
            ),
          ),
        ),
      body: new Container(

        color: Colors.white,
        child: new Container(
          child:  FutureBuilder(
            future: app,
            builder: (context , snapShot) {
              if(snapShot.hasData) {
                return SingleChildScrollView(
                  child: new Container(
                    child: new Container(
                      decoration: new BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border(
                              left: BorderSide(
                                  color: Colors.grey,
                                  style: BorderStyle.solid
                              ),
                              right: BorderSide(
                                  color: Colors.grey,
                                  style: BorderStyle.solid
                              ),
                              bottom: BorderSide(
                                  color: Colors.grey,
                                  style: BorderStyle.solid
                              ),
                              top: BorderSide(
                                  color: Colors.grey,
                                  style: BorderStyle.solid
                              )
                          )

                      ),
                      width: MediaQuery.of(context).size.width,
                      margin: EdgeInsets.all(10),
                      height: MediaQuery.of(context).size.height/1.3,
                      child: new Column(
                        children: [
                          new SizedBox(height: 10,),
                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.category, color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.category, style: new TextStyle(fontSize: 20))
                            ],
                          ),
                          SizedBox(height: 10,),

                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.star_rate, color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.rating, style: new TextStyle(fontSize: 20),),
                              new SizedBox(width: MediaQuery.of(context).size.width/3,),
                              new Icon(Icons.rate_review,color: Colors.purple, size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.review, style: new TextStyle(fontSize: 20),),

                            ],
                          ),
                          new SizedBox(height: 10,),
                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.format_size, color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.size, style: new TextStyle(fontSize: 13),),
                              new SizedBox(width: MediaQuery.of(context).size.width/3,),
                              new Icon(Icons.save,color: Colors.purple, size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.installs, style: new TextStyle(fontSize: 13),),

                            ],
                          ),
                          new SizedBox(height: 10,),
                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.merge_type, color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.type, style: new TextStyle(fontSize: 14),),
                              new SizedBox(width: MediaQuery.of(context).size.width/3,),
                              new Icon(Icons.money,color: Colors.purple, size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.price, style: new TextStyle(fontSize: 20),),

                            ],
                          ),
                          new SizedBox(height: 10,),
                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.account_box_outlined, color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.content_range, style: new TextStyle(fontSize: 15),),
                              new SizedBox(width: MediaQuery.of(context).size.width/4,),
                              new Icon(Icons.android,color: Colors.purple, size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.android_veersion, style: new TextStyle(fontSize: 14),),

                            ],
                          ),
                          new SizedBox(height: 10,),
                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.toc_sharp , color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.genres, style: new TextStyle(fontSize: 20))
                            ],
                          ),
                          SizedBox(height: 10,),
                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.last_page, color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.last_update, style: new TextStyle(fontSize: 20))
                            ],
                          ),
                          SizedBox(height: 10,),
                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.trending_up_rounded, color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.current_version, style: new TextStyle(fontSize: 20))
                            ],
                          ),
                          SizedBox(height: 10,),
                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.create_rounded, color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.created_at, style: new TextStyle(fontSize: 20))
                            ],
                          ),
                          SizedBox(height: 10,),
                          new Row(
                            children: [
                              new SizedBox(width: 10,),
                              new Icon(Icons.update_rounded, color: Colors.purple,size: 30,),
                              new SizedBox(width: 20,),
                              new Text(snapShot.data.updated_at, style: new TextStyle(fontSize: 20))
                            ],
                          ),
                          SizedBox(height: 10,),


                        ],
                      ),
                    ),
                  ),
                );
              } else {
                return new Center(child: new Text("not found!"),);
              }
            },
          ),
        )
      ),

    );
  }
}
