import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:rezataster/search_screen.dart';

import 'appsModule.dart';
import 'cartshow_page.dart';

class CategoriesItem extends StatefulWidget {
  final String cat;
  CategoriesItem({this.cat});
  @override
  _CategoriesItemState createState() => _CategoriesItemState();
}

class _CategoriesItemState extends State<CategoriesItem> {

  List<AppsModule> apps = new List();


  getResponse() async {


    var response = await http.get("http://se.bot-telegram99.ir/api/search?search=${widget.cat}");
    // print(response.body.toString());
    List<dynamic> jsonData = json.decode(response.body);


    // print(response.statusCode);
    setState(() {
      print(jsonData);
      AppsModule app = new AppsModule();
      jsonData.forEach((element) {
        app = AppsModule.fromJson(element);
        apps.add(app);
      });
    });
    print(apps);
  }



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getResponse();

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
          backgroundColor: Colors.purple,
          title: Container(
            width: MediaQuery.of(context).size.width,
            decoration: new BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.white
            ),
            child: new TextField(
              decoration: new InputDecoration(

                  prefixIcon: new Icon(Icons.search , color: Colors.grey,),
                  border: InputBorder.none,
                  hintText: widget.cat
              ),
              readOnly: true,
              onTap: () {
                Navigator.of(context).push(
                    new MaterialPageRoute(builder: (context) => SearchScreen())
                );
              },
            ),
          ),
        ),
      body: Container(

        child: new GridView.builder(
          itemCount: apps.length,
          addAutomaticKeepAlives: true,
          itemBuilder: (BuildContext context, int index) {

            return GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    new MaterialPageRoute(builder: (context) => ShowDetail(app: apps[index],))
                );
              },
              child: Container(
                height: 200,
                width: MediaQuery.of(context).size.width/2,
                decoration: new BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),

                ),
                margin: EdgeInsets.all(10),
                child: new Column(
                  children: [
                    new CircleAvatar(
                      backgroundColor: Colors.orangeAccent[700],
                      child: new Center(child: new Text(apps[index].id.toString(),style: new TextStyle(color: Colors.white,),)),
                    ),
                    SizedBox(height: 10,),
                    new Text(apps[index].name, maxLines: 3,),
                    SizedBox(height: 25,),
                    new Container(
                      child: Center(child: new Text(apps[index].type, style: new TextStyle(color: Colors.white, fontSize: 20),)),
                      decoration: new BoxDecoration(
                          color: Colors.orangeAccent[700],
                          borderRadius: BorderRadius.circular(14)
                      ),
                      height: 50,
                      width: 100,
                    )
                  ],
                ),
              ),
            );
          },
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        ),
      ),
    );
  }
}
