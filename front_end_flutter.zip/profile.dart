
import 'package:flutter/material.dart';
import 'package:rezataster/categories_item.dart';
import 'package:rezataster/ratingDetail.dart';

class RatingScreen extends StatefulWidget {
  @override
  RatingScreenState createState() => RatingScreenState();
}

class RatingScreenState extends State<RatingScreen> {

  List<String> ratingRange = [
    "between 1 to 2",
    "between 2 to 3",
    "between 3 to 4",
    "between 4 to 5"
  ];


  @override
  Widget build(BuildContext context) {
    return Container(

      child: new Container(
        child: new ListView.builder(
          itemCount: ratingRange.length,
          itemBuilder: (BuildContext context , int index) {
            return GestureDetector(
              onTap: () {
                print(ratingRange[index]);
                Navigator.of(context).push(
                    new MaterialPageRoute(builder: (context) => RatingDetail(from: index + 1, to: index+2,))
                );
              },
              child: new Container(
                margin: EdgeInsets.all(10),
                decoration: new BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border(
                        left: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        ),
                        right: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        ),
                        bottom: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        ),
                        top: BorderSide(
                            color: Colors.grey,
                            style: BorderStyle.solid
                        )
                    )

                ),
                height: 40,
                child: new Center(child: new Text(ratingRange[index])),
              ),
            );
          },
        ),
      )
    );
  }
}
