import 'package:flutter/material.dart';

import 'home_page.dart';


void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'googlePlayStore', home: HomePage() , debugShowCheckedModeBanner: false,);
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  int switchNum= 0;

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: new Stack(
        children: [

          new Container(
            decoration: new BoxDecoration(
                image: DecorationImage(
                    image: new AssetImage("assets/images/wallpaper.jpg"),
                    fit: BoxFit.cover
                )
            ),
          ),

          Align(
            alignment: Alignment.center,
            child: new Container(

              child: new Center(
                child: new Column(
                  children: [
                    SizedBox(height: 10,),
                    new Row(
                      children: [
                        new GestureDetector(
                            onTap: () {
                              setState(() {
                                switchNum = 0;
                              });
                            },
                            child: new Container(
                              margin: EdgeInsets.only(left: size.width / 3),
                              width: 15,
                              height: 15,
                              decoration: new BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: new Border(
                                      bottom: BorderSide(
                                          color: Colors.orange                        ),
                                      top: BorderSide(
                                          color: Colors.orange                        ),
                                      left: BorderSide(
                                          color: Colors.orange
                                      ),
                                      right: BorderSide(
                                          color: Colors.orange                        )
                                  ),
                                  color: switchNum == 0 ? Colors.orange :Colors.white.withOpacity(0.95)
                              ),
                            )
                        ),
                        SizedBox(width: 10,),
                        new GestureDetector(
                            onTap: () {
                              setState(() {
                                switchNum = 1;
                              });
                            },
                            child: new Container(
                              width: 15,
                              height: 15,
                              decoration: new BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: new Border(
                                      bottom: BorderSide(
                                          color: Colors.orange                        ),
                                      top: BorderSide(
                                          color: Colors.orange                        ),
                                      left: BorderSide(
                                          color: Colors.orange
                                      ),
                                      right: BorderSide(
                                          color: Colors.orange                        )
                                  ),
                                  color: switchNum == 1 ? Colors.orange :Colors.white.withOpacity(0.95)
                              ),
                            )
                        ),
                        SizedBox(width: 10,),
                        new GestureDetector(
                            onTap: () {
                              setState(() {
                                switchNum = 2;
                              });
                            },
                            child: new Container(
                              width: 15,
                              height: 15,
                              decoration: new BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: new Border(
                                      bottom: BorderSide(
                                          color: Colors.orange                        ),
                                      top: BorderSide(
                                          color: Colors.orange                        ),
                                      left: BorderSide(
                                          color: Colors.orange
                                      ),
                                      right: BorderSide(
                                          color: Colors.orange                        )
                                  ),
                                  color: switchNum == 2 ? Colors.orange :Colors.white.withOpacity(0.95)
                              ),
                            )
                        ),
                        SizedBox(width: 10,),

                      ],
                    ),
                    SizedBox(height: 25,),
                    new Text(switchNum == 0 ? "WELCOME TO MSTORE" : switchNum == 1 ?"ALL APPS LS FREE!!!" : "GO AND ENGOY :)", style: new TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 32),),
                    SizedBox(height: 25,),
                    switchNum == 2 ? Padding(
                      padding: EdgeInsets.symmetric(horizontal: size.width / 6, vertical: 10),
                      child: new RaisedButton(
                        padding: EdgeInsets.all(20),
                        child: new Center(child: new Text("Get Start" , style: new TextStyle(color: Colors.white , fontSize: 30 , fontWeight: FontWeight.bold),),),
                        color: Colors.orange,
                        elevation: 0,
                        onPressed: () {
                          return Navigator.of(context).pushReplacement(
                              new MaterialPageRoute(
                                  builder: (context) => MainHomePage()
                              )
                          );
                        },
                      ),
                    ) : new Text( switchNum == 0 ? "Access to more than 10000 app" : "you can save download file and share them", style: TextStyle(color: Colors.grey , fontSize: 20),maxLines: 2,)
                  ],
                ),
              ),
              width: size.width * 0.8,
              height: size.height / 3.8,
              decoration: new BoxDecoration(
                  color: Colors.white.withOpacity(0.95),
                  borderRadius: BorderRadius.circular(50)
              ),

            ),
          )
        ],
      ),
    );
  }
}
