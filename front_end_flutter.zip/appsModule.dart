
class AppsModule {

  final int id;
  final String name;
  final String category;
  final String rating;
  final String review;
  final String size;
  final String installs;
  final String type;
  final String price;
  final String content_range;
  final String genres;
  final String last_update;
  final String current_version;
  final String android_veersion;
  final String created_at;
  final String updated_at;


  AppsModule({this.size,this.id, this.android_veersion,this.category, this.content_range, this.created_at,this.current_version,this.genres,this.installs,this.last_update,this.name,this.price,
  this.rating,this.review, this.type, this.updated_at});

  factory AppsModule.fromJson(Map<String, dynamic> jsonData){
    return AppsModule(
      id: jsonData['id'],
      name: jsonData['name'],
      category: jsonData['category'],
      rating: jsonData['rating'],
      review: jsonData['reviews'],
      size: jsonData['size'],
      installs: jsonData['installs'],
      type: jsonData['type'],
      price: jsonData['price'],
      content_range: jsonData['content_range'],
      genres: jsonData['genres'],
      last_update: jsonData['last_update'],
      current_version: jsonData['current_version'],
      android_veersion: jsonData['android_version'],
      created_at: jsonData['created_at'],
      updated_at: jsonData['updated_at']
    );
  }
}