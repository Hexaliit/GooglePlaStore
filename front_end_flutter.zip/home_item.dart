import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:rezataster/appsModule.dart';

import 'cartshow_page.dart';

class HomeItem extends StatefulWidget {
  @override
  HomeItemState createState() => HomeItemState();
}

class HomeItemState extends State<HomeItem> {

  List<AppsModule> apps = new List();
  static List<AppsModule> allApp = new List();
  ScrollController _listScrollController= new ScrollController();
  int _currentPage = 1;
  bool isLoading = true;
  
  getResponse(int page) async {


    var response = await http.get("http://se.bot-telegram99.ir/api/apps?page=${page}");
    // print(response.body.toString());
    Map<String, dynamic> jsonData = json.decode(response.body);
    // print(response.statusCode);
    setState(() {
      jsonData["data"].forEach((element) {
        AppsModule app = new AppsModule();
        app = AppsModule.fromJson(element);
        apps.add(app);
      });
    });


    return {
      "current_page" : jsonData['current_page'],
      "apps" : apps
    };
  }

  _getApps({int page : 1, bool refresh: true}) async {
    setState(() {
      isLoading = true;
    });

    var response = await getResponse(page);
    setState(() {
      if(!refresh) allApp.clear();
      allApp.addAll(response['apps']);
      _currentPage = response["current_page"];
      isLoading = false;
    });

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _getApps();

    _listScrollController.addListener(() {
      double maxScroll = _listScrollController.position.maxScrollExtent;
      double currentScroll = _listScrollController.position.pixels;

      if(maxScroll - currentScroll <= 200) {
        if(!isLoading) {
          _currentPage++;
          _getApps(page: _currentPage, refresh: false);
          print(_currentPage);
        }
      }
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Container(

      child: new GridView.builder(
        itemCount: allApp.length,
        addAutomaticKeepAlives: true,
        controller: _listScrollController,
        itemBuilder: (BuildContext context, int index) {

          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                new MaterialPageRoute(builder: (context) => ShowDetail(app: allApp[index],))
              );
            },
            child: Container(
              height: 200,
              width: MediaQuery.of(context).size.width/2,
              decoration: new BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),

              ),
              margin: EdgeInsets.all(10),
              child: new Column(
                children: [
                  new CircleAvatar(
                    backgroundColor: Colors.orangeAccent[700],
                    child: new Center(child: new Text(allApp[index].id.toString(),style: new TextStyle(color: Colors.white,),)),
                  ),
                  SizedBox(height: 10,),
                  new Text(allApp[index].name, maxLines: 3,),
                  SizedBox(height: 25,),
                  new Container(
                    child: Center(child: new Text(allApp[index].type, style: new TextStyle(color: Colors.white, fontSize: 20),)),
                    decoration: new BoxDecoration(
                      color: Colors.orangeAccent[700],
                      borderRadius: BorderRadius.circular(14)
                    ),
                    height: 50,
                    width: 100,
                  )
                ],
              ),
            ),
          );
        },
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
      ),
    );
  }
}
