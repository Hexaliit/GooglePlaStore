import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:rezataster/categories_item.dart';

class GenresScreen extends StatefulWidget {
  @override
  GenresScreenState createState() => GenresScreenState();
}

class GenresScreenState extends State<GenresScreen> {

  Future<dynamic> categories;
  getCategory() async {

    var response = await http.get('http://se.bot-telegram99.ir/api/genres');
    var jsonData = json.decode(response.body);
    return jsonData;
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    categories = getCategory();
  }
  @override
  Widget build(BuildContext context) {
    return Container(

      child: FutureBuilder(
        future: categories,
        builder: (context , snapShot) {
          if(snapShot.hasData) {
            return new Container(
              child: new ListView.builder(
                itemCount: snapShot.data.length,
                itemBuilder: (BuildContext context , int index) {
                  return GestureDetector(
                    onTap: () {
                      print(snapShot.data[index].toString());
                      Navigator.of(context).push(
                          new MaterialPageRoute(builder: (context) => CategoriesItem(cat: snapShot.data[index].toString()))
                      );
                    },
                    child: new Container(
                      margin: EdgeInsets.all(10),
                      decoration: new BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border(
                              left: BorderSide(
                                  color: Colors.grey,
                                  style: BorderStyle.solid
                              ),
                              right: BorderSide(
                                  color: Colors.grey,
                                  style: BorderStyle.solid
                              ),
                              bottom: BorderSide(
                                  color: Colors.grey,
                                  style: BorderStyle.solid
                              ),
                              top: BorderSide(
                                  color: Colors.grey,
                                  style: BorderStyle.solid
                              )
                          )

                      ),
                      height: 40,
                      child: new Center(child: new Text(snapShot.data[index].toString())),
                    ),
                  );
                },
              ),
            );
          } else {
            return new Center(child: new Text("no Genres founded"),);
          }
        },
      ),
    );
  }
}
